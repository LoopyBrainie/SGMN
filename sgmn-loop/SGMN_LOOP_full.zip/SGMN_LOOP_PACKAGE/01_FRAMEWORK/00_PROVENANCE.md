# 01_FRAMEWORK · 本 loop 的**唯一框架来源**

> 生成：2026-11-15 06:03:34 UTC

| 文件 | md5 | 说明 |
|---|---|---|
| `SGMN_v2.4_架构设计.md` | `48ac8d6b8914f8ac0026ed6df746e934` | ★ **v2.4 架构设计原文** —— 本 loop 的唯一框架来源（§7.2 派生每个方向的 source） |
| `神经网络多尺度方程的完整推导：从微观到宏观.txt` | `dfd77deacd9409a0c885838ce923842a` | 上游附件（背景材料，非判据来源） |
| `记忆型LLM双系统.docx` | `9ed69c6f9d90e378f197621e64b5b682` | 上游附件（背景材料，非判据来源） |

## 语料（不入包，按 md5 复原）

| 文件 | md5 | 来源 |
|---|---|---|
| `corpus/train.txt` | `34a77ebe59551b3a3b3d8c0a2797c976` | `https://cdn.jsdelivr.net/gh/pytorch/examples@main/word_language_model/data/wikitext-2/` |
| `corpus/valid.txt` | `d756d22ab2310e7e60c094bea5c5a8eb` | 同上 |

> 模型权重同样不入包：`Qwen/Qwen2.5-0.5B-Instruct`（float32，md5 见卡片）。
