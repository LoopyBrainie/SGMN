# SGMN v2.4 架构验证 Loop · 完整交付包

> 生成：2026-11-15 06:03:42 UTC
> 范围：**DIR-01…DIR-19 已闭合；DIR-20（跨会话状态语义）进行中**；`SUCCEEDED = 14/14`（**DIR-18 已 COMPLETE / SUCCESS** ⇒ 主假说【证实】）

| 目录 | 内容 |
|---|---|
| `01_FRAMEWORK/` | **v2.4 架构设计原文**（本 loop 的唯一框架来源）+ 上游附件 + `00_PROVENANCE.md`（md5 与来源） |
| `02_ROUNDS/` | 各方向的**装置 / 脚本 / 探针**（自包含单文件，附 md5 记录） |
| `03_LEDGERS/` | 证据表 / 证据台账 / 方向登记表 / loop 机制 / 修订记录 / MANIFEST / 报告 |
| `04_EVIDENCE/` | 各方向的**卡片（全部 revision）与裁决书**、结果 JSON |
| `05_LOGS/` | 全部实验日志（含 **CPU 降级轮**的完整日志与增量落盘） |
| `06_CONTINUITY/` | 运维 / 审计 / 打包脚本（**可复现性资产**） |
| `07_BUNDLES/` | 各方向的独立产物包 |

## 校验

```bash
cd SGMN_LOOP_PACKAGE && md5sum -c 00_MANIFEST.md
```

## ★ 阅读顺序建议

1. `03_LEDGERS/evidence_table.md` —— **证据表**（只增行、不改行；含每条的「支持范围」与「不能外推为」）
2. `03_LEDGERS/SUMMARY.md` —— 全 loop 摘要
3. `03_LEDGERS/LOOP-MECHANISM.md` —— **loop 机制 + 46 条机制级纪律**
4. `03_LEDGERS/REPORT.md` —— 完整报告
5. `04_EVIDENCE/DIR-20/VERDICT.md` —— 最近一方向的裁决书（**跨会话状态语义**：折损 = 0，但收益的 69% 是通用注入）

## ★ 一句话结论

**v2.4 的实际写规则（Hebbian，键逐写归一化）在冻结基座上可用**，且**状态可跨会话搬运**（折损 = 0）；
但**「记忆内容」只解释任务收益的一部分**（跨会话：内容特异 +1.72 / 通用注入 +3.79）
⇒ ⇒ **「注入记忆结构 ≠ 召回记忆内容」**，任何只报告总收益的记忆结论都是不充分的。
