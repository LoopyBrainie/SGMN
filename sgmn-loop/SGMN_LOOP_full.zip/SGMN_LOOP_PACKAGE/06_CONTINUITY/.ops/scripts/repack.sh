#!/bin/bash
# DIR-18 · 打包：更新 DIR-18_artifacts.zip / 两个 full zip / MANIFEST，并逐文件 md5 复核
set -u
# ★ 路径可移植（2026-11-07）：原实现硬编码 `/workspace/sgmn-loop`（旧沙箱布局）⇒
#   实验卷上运行时报错 ⇒ ⇒ 改为**环境变量优先 + 默认当前工作区**（不改变任何逻辑）。
ROOT=${SGMN_ROOT:-/home/ec2-user/sgmn-loop}
LOG=$ROOT/.ops_pack.log
say() { echo "[$(date -u +%H:%M:%S)] $*" | tee -a "$LOG"; }

say "===== DIR-18 打包开始 ====="

# ---------- ① DIR-18 产物包 ----------
# ★ 2026-11-07：恢复后的工作区里 DIR-18 在**顶层** `dir18/`（旧沙箱布局是 `revolve/DIR-18/`）。
rm -f "$ROOT/DIR-18_artifacts.zip"
cd "$ROOT/dir18" && zip -qr "$ROOT/DIR-18_artifacts.zip" \
  DIRECTION_rev15.md VERDICT.md \
  sgmn_module_hebb.py sgmn_module_hebb_v2.py \
  R1_write.py R2_write.py R4_formal.py \
  rounds probes pipeline18.sh probe18*.py probe18*_out.json \
  -x "*__pycache__*" -x "*.server.py" 2>/dev/null
say "DIR-18_artifacts.zip = $(stat -c%s "$ROOT/DIR-18_artifacts.zip") B"

# ---------- ①' DIR-19 产物包（新增）----------
rm -f "$ROOT/DIR-19_artifacts.zip"
cd "$ROOT/revolve/DIR-19" && zip -qr "$ROOT/DIR-19_artifacts.zip" \
  DIRECTION.md DIRECTION_rev11.md DIRECTION_rev12.md DIRECTION_rev13.md DIRECTION_rev14.md DIRECTION_rev15.md \
  sgmn_module_hebb_v3.py R1_protect.py VERDICT.md IMPLEMENTATION-PLAN.md \
  -x "*__pycache__*" -x "*.server.py" 2>/dev/null
say "DIR-19_artifacts.zip = $(stat -c%s "$ROOT/DIR-19_artifacts.zip") B"

# ---------- ①'' DIR-20 产物包（跨会话状态语义）----------
rm -f "$ROOT/DIR-20_artifacts.zip"
cd "$ROOT/revolve/DIR-20" && zip -qr "$ROOT/DIR-20_artifacts.zip" \
  DIRECTION.md DIRECTION_rev11.md DIRECTION_rev12.md DIRECTION_rev13.md \
  DIRECTION_rev14.md DIRECTION_rev15.md DIRECTION_rev16.md \
  sgmn_module_hebb_v4.py sgmn_module_hebb_v5.py sgmn_module_hebb_v6.py \
  R1_xsession.py VERDICT.md R20_results.json \
  _blk_arms.py _blk_readonly.py _blk_main.py _blk_crit.py _blk_stageA.py \
  assemble_dir20.py D20_R1_smoke.log D20_R1_smoke2.log D20_R1_smoke3.log \
  D20_R1_smoke4.log D20_R1_smoke5.log D20_R1_smoke6.log D20_R1_smoke7.log \
  D20_R1_smoke8.log D20_R2_formal.log D20_R2_formal_attempt2_diskfull.log \
  -x "*__pycache__*" -x "*.server.py" 2>/dev/null
say "DIR-20_artifacts.zip = $(stat -c%s "$ROOT/DIR-20_artifacts.zip") B"
# ---------- ①''' DIR-21 产物包（时间与情节状态（一）· COMPLETE / FALSIFIED）----------
rm -f "$ROOT/DIR-21_artifacts.zip"
cd "$ROOT/revolve/DIR-21" && zip -qr "$ROOT/DIR-21_artifacts.zip" \
  DIRECTION_rev21.md DIRECTION_rev21_rev11.md \
  DIRECTION_rev21_v12.md DIRECTION_rev21_v13.md DIRECTION_rev21_v14.md \
  DIRECTION_rev21_v15.md DIRECTION_rev21_v16.md DIRECTION_rev21_v17.md \
  DIRECTION_rev21_v18.md sgmn_module_hebb_v7.py R1_granularity.py VERDICT.md \
  probe21_capacity.py probe21b_decay.py probe21c_task.py \
  -x "*__pycache__*" -x "*.server.py" 2>/dev/null
say "DIR-21_artifacts.zip = $(stat -c%s "$ROOT/DIR-21_artifacts.zip") B"


# ---------- ② full 包（交给自足版 rebuild_full.sh：持久卷暂存 + 从零重建 + 完整性断言）----------
# ★ 缺陷 D61：原实现在此处建 `/tmp/SGMN_LOOP_PACKAGE` 并只做增量拷贝 ⇒ 沙箱回收后
#   **完整包静默缩水 368 → 39 文件**且零报错。现统一由 rebuild_full.sh 自足重建。

# ---------- ③ MANIFEST ----------
cd "$ROOT"
{
  # ★ 2026-11-09（DIR-26-N 收口）：原实现把标题与目录**写死**在 DIR-21（"SUCCEEDED = 15/15"）
  #   ⇒ 每多一轮就与台账**不一致**（实测 MANIFEST.md 自 2026-11-07 起停在 DIR-21/15-15）。
  #   改为**从活文档现读**：SUCCEEDED 取 `SUMMARY.md` 的头部，方向目录**按 `revolve/DIR-*` + `dir*` 自动枚举**。
  _SUCC=$(grep -o "SUCCEEDED = [0-9]* / [0-9]*" "$ROOT/SUMMARY.md" | head -1)
  _NDIR=$(ls -d "$ROOT"/revolve/DIR-* 2>/dev/null | wc -l)
  echo "# MANIFEST · SGMN Loop（\`revolve/DIR-*\` 目录 ${_NDIR} 个〔非方向总数〕；${_SUCC:-SUCCEEDED 未读到}）"
  echo
  echo "> 生成：$(date -u "+%Y-%m-%d %H:%M:%S") UTC"
  echo "> 校验：逐文件 md5（\`md5sum -c\`）"
  echo
  echo "## 核心台账"
  find . -maxdepth 2 -name "*.md" -not -path "./.ops*" -not -name "MANIFEST.md" | sort | while read -r f; do
    md5sum "$f"
  done
  echo
  echo "## 各方向产物（自动枚举）"
  for _d in "$ROOT"/revolve/DIR-* "$ROOT"/dir*; do
    [ -d "$_d" ] || continue
    case "$(basename "$_d")" in __pycache__|.ops) continue ;; esac
    echo
    echo "### $(basename "$_d")"
    ( cd "$ROOT" && find "./${_d#"$ROOT"/}" -type f -not -path "*__pycache__*" -not -path "*.ops/*" | sort ) | while read -r f; do
      md5sum "$f"
    done
  done
  echo
  echo "## 证据表与台账"
  md5sum ./evidence/table.md ./evidence/ledger.md
} > "$ROOT/MANIFEST.md"
say "MANIFEST.md = $(wc -l < "$ROOT/MANIFEST.md") 行"

# ---------- ④ 校验 ----------
cd "$ROOT"
grep -E "^[0-9a-f]{32}  " MANIFEST.md > /tmp/_mf.txt
md5sum -c /tmp/_mf.txt > /tmp/_mf_check.txt 2>&1
OK=$(grep -c ": OK$" /tmp/_mf_check.txt)
BAD=$(grep -c ": FAILED$" /tmp/_mf_check.txt)   # ★ 只匹配行尾的 FAILED（文件名里含 "FAILED" 不算失败）
say "MANIFEST 校验：OK=$OK  FAILED=$BAD"
if [ "$BAD" != "0" ]; then grep "FAILED" /tmp/_mf_check.txt | head -20 | tee -a "$LOG"; fi
# ---------- ⑤ full 包重建（自足版）----------
# ★ DEF-26P-10（补）：原实现**不检查退出码** ⇒ 完整包构建失败时仍打印「打包结束」（假成功）
if ! bash "$ROOT/.ops/scripts/rebuild_full.sh"; then
  say "★★ 完整包构建失败（非零退出）⇒ 打包失败，**不打印「打包结束」**"; exit 1
fi
say "===== 打包结束（全部校验通过）====="
